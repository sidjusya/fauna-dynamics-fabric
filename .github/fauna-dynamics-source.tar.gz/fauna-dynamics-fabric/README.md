# Fauna Dynamics

**A vanilla-friendly expansion of animal behavior for Minecraft Java 26.3 (Fabric).**

Fauna Dynamics adds small, situational behaviors to vanilla animals instead of replacing them with completely new mobs.

> Current project status: `0.1.0-alpha.1` source preview. The initial behavior pass covers every animal group in the design. Client-side model animation rendering, a dedicated animation-state network payload, and visible ram/bull horn geometry are not yet implemented in this alpha.

## Target platform

- Minecraft Java: `26.3`
- Java: `25`
- Fabric Loader: `0.20.1`
- Fabric Loom: `1.19-SNAPSHOT`
- Fabric API: `0.166.2+26.3` (current 26.3 release)

## First-version behavior scope

- **Horses:** untamed adult horses can kick at a nearby threat behind them. Default damage is 9 health points (4.5 hearts), with 3 seconds of Slowness.
- **Sheep and rams:** sheep receive a persistent male/female trait. Adult rams can compete when adult ewes are nearby; the new behavior does not deal damage.
- **Goats:** adult male goats can challenge one another with a head-butt style shove. Vanilla goat ramming remains unchanged.
- **Cows and bulls:** cows receive a persistent male/female trait. A bull can retaliate after a player hits it, make a limited number of counterattacks, then disengage.
- **Cats:** breeding can produce litters of 3–6 kittens. Adult cats can approach dropped items and other cats for short play interactions.
- **Tamed wolves (dogs):** breeding has a 50% chance of one pup and a 50% chance of 2–3 pups. Dogs can play with other dogs, perform a harmless digging effect, and make non-damaging practice chases near sheep or skeletons.
- **Chickens:** breeding can produce 2–4 chicks. The vanilla egg hatch roll is preserved; a successful hatch can add 1–2 sibling chicks. Chicks follow nearby adult chickens.

The litter counts include the baby already created by vanilla Minecraft.

## Animation implementation status

The server-side prototype currently drives behavior and movement only. Visible model-part animation hooks and server-to-client animation-state networking are not implemented in this alpha. The next client pass will add native model rotations without a third-party animation library. Planned poses include the horse kick, ram/goat/bull preparation and impact, cat play, and dog digging/play.

Male/female traits are stored as persistent vanilla entity tags and survive save/reload. They currently affect behavior only; visible ram and bull horn geometry is still on the model-rendering task list.

## Configuration

On first launch the mod creates:

`config/fauna-dynamics.json`

The file contains tunable values for probabilities, litter sizes, damage, cooldown checks, and behavior frequency. The game must be restarted for changed values to be reloaded in this alpha.

## Build

Use JDK 25 and Gradle 9.8.2. In IntelliJ IDEA, open this directory as a Gradle project and run the `build` task, or run:

```bash
gradle --no-daemon clean build
```

The remapped mod JAR is produced in:

```text
build/libs/
```

A GitHub Actions workflow builds the project on pushes, pull requests, and manual workflow dispatch, then uploads the resulting JAR as an Actions artifact.

## Testing

See [the in-game testing checklist](docs/testing-checklist.md) before calling this alpha stable. This source preview has not yet been compiled or tested in a Minecraft 26.3 client.

## Repository

https://github.com/sidjusya/fauna-dynamics-fabric

## License

MIT. See [LICENSE](LICENSE).
