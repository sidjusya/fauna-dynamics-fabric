# Native animation plan

The current server-side behavior has no client animation-state transport yet. A dedicated Fabric payload will carry short-lived pose states in a later pass; the mod will not add entries to vanilla `SynchedEntityData`, avoiding ID collisions with other mods.

| Animal | Action IDs | Planned native pose |
|---|---|---|
| Horse | `HORSE_KICK` | Look back, shift the body forward, raise hindquarters, extend both hind legs |
| Ram | `RAM_PREPARE`, `RAM_IMPACT` | Lower head, short approach, head impact and recoil |
| Goat | `GOAT_PREPARE`, `GOAT_IMPACT` | Lower head, short approach, head impact and recoil |
| Bull | `BULL_CHARGE` | Lower head and short forward movement |
| Cat | `CAT_PLAY` | Crouch, roll to the side/back, paw at a nearby item or playmate |
| Dog | `DOG_DIG`, `DOG_PLAY` | Lower front body and alternate front paws; playful chase posture |

Implementation notes:

- Add a dedicated server-to-client payload for short-lived animation states.
- Use the stock model parts and interpolate angles on the client.
- Avoid replacing vanilla movement or attack logic where a small pose adjustment is enough.
- Add the visible ram/bull horn geometry as model parts in the same client-side pass.
- Test all adult and baby model variants separately.

This document is a plan, not a claim that these rendered poses are already complete.
