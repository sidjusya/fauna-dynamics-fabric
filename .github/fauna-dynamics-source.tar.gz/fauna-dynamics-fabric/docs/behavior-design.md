# Behavior design notes

## Shared rules

- AI decisions and damage are server-authoritative.
- New behaviors are occasional, not constant background actions.
- An action uses a cooldown so nearby animals do not continuously repeat it.
- New dog practice interactions never apply damage to sheep or skeletons.
- Digging is decorative in the first implementation and does not remove blocks.
- Existing vanilla breeding and egg hatching remain the starting point; the mod adds siblings only after vanilla succeeds.

## Sex variants

The male/female flag is assigned once to an individual and saved as a vanilla entity tag. Current initial chances are 30% male sheep, 35% male goats, and 15% male cows. The flag is not yet sent to client renderers; that will use a separate mod network payload rather than vanilla entity-data IDs.

## Initial default values

| Behavior | Default |
|---|---:|
| Untamed horse kick chance per 5-second check | 20% |
| Horse kick damage | 9 health (4.5 hearts) |
| Horse Slowness | 60 ticks (3 seconds) |
| Ram population chance | 30% male |
| Bull population chance | 15% male |
| Goat population chance | 35% male |
| Dog practice chase chance per social check | 4% |
| Bull retaliation damage | 4 health (2 hearts) |
| Bull retaliation attacks | 2 |
| Cat litter | 3–6 kittens |
| Dog single-pup chance | 50% |
| Dog multiple-pup litter | 2–3 pups |
| Chicken breeding litter | 2–4 chicks |
| Extra chicks after a successful egg hatch | 1–2 |

All values are configurable in `fauna-dynamics.json`.
