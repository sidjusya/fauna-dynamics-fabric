# In-game testing checklist

Run these checks in a fresh test world after a successful Java 25 / Minecraft 26.3 Fabric build.

## General

- [ ] The game starts with Fabric Loader 0.20.1+ and Fabric API 0.167.0+26.3.
- [ ] The config file is created in `config/fauna-dynamics.json`.
- [ ] Config values outside their supported range are clamped; tick intervals are rounded to multiples of five.
- [ ] Entity sex traits survive save, quit, and reload.
- [ ] No custom behavior runs twice on the client and server.

## Horses

- [ ] Untamed adult horses can kick a target positioned behind them.
- [ ] Tamed and baby horses do not use the kick behavior.
- [ ] Damage and Slowness duration match the config.
- [ ] A horse does not repeatedly kick during its cooldown.

## Sheep, rams, goats, cows, and bulls

- [ ] Adult sheep receive a persistent male/female trait; the configured male ratio is respected over a large sample.
- [ ] Rams only seek a rival while adult ewes are nearby.
- [ ] A ram contest ends in a shove/recoil and applies a cooldown to both participants.
- [ ] Only adult male goats initiate the new goat-to-goat contest.
- [ ] Bulls only retaliate after being hit by a player, perform a limited number of counterattacks, and then disengage.

## Cats and dogs

- [ ] Cat breeding produces 3–6 kittens in total, including the vanilla-spawned kitten.
- [ ] Tamed wolf breeding produces one puppy 50% of the time and 2–3 total the other 50%.
- [ ] Cats approach dropped items and other cats/animals for brief play interactions.
- [ ] Tamed adult wolves can play with another tamed adult wolf.
- [ ] Dog digging is decorative and does not change blocks.
- [ ] Practice chases do not apply damage to sheep or skeletons.
- [ ] Young cats and dogs follow a nearby adult of their species.

## Chickens

- [ ] Chicken breeding produces 2–4 chicks in total.
- [ ] A successful vanilla egg hatch produces 2–3 chicks in total.
- [ ] The vanilla one-in-eight egg hatch chance is unchanged.
- [ ] Chicks follow nearby adult chickens.

## Multiplayer and compatibility

- [ ] Test on a dedicated server with at least one remote client.
- [ ] Confirm that only the server applies damage and creates extra offspring.
- [ ] Test alongside another mod that adds entity data to vanilla animals.
- [ ] Check logs for mixin warnings, missing injection targets, and duplicate entity UUIDs.
