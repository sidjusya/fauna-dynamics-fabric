# Changelog

## 0.1.0-alpha.1 — source preview

- Added a server-side behavior prototype covering horses, sheep/rams, goats, cows/bulls, cats, tamed wolves (dogs), and chickens.
- Added persistent male/female traits for sheep, goats, and cows.
- Added configurable multi-offspring behavior for cats, dogs, and chickens, including successful egg hatches.
- Added a configurable JSON file and a Java 25 GitHub Actions build workflow.
- Native rendered animations, visible ram/bull horns, and client animation-state networking remain unfinished.
