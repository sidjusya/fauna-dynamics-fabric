package com.faunadynamics.mixin;

import com.faunadynamics.config.FaunaConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownEgg;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ThrownEgg.class)
abstract class ThrownEggMixin {
    @Unique
    private boolean faunaDynamics$vanillaEggHatched;

    @Inject(method = "onHit", at = @At("HEAD"), require = 0)
    private void faunaDynamics$resetHatchFlag(HitResult hitResult, CallbackInfo ci) {
        faunaDynamics$vanillaEggHatched = false;
    }

    /** Records vanilla's existing 1-in-8 hatch roll without changing its probability. */
    @Redirect(
            method = "onHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/RandomSource;nextInt(I)I",
                    ordinal = 0
            ),
            require = 0
    )
    private int faunaDynamics$recordHatchRoll(RandomSource random, int bound) {
        int result = random.nextInt(bound);
        if (bound == 8 && result == 0) faunaDynamics$vanillaEggHatched = true;
        return result;
    }

    @Inject(method = "onHit", at = @At("TAIL"), require = 0)
    private void faunaDynamics$addHatchSiblings(HitResult hitResult, CallbackInfo ci) {
        if (!faunaDynamics$vanillaEggHatched) return;
        ThrownEgg egg = (ThrownEgg) (Object) this;
        if (!(egg.level() instanceof ServerLevel level)) return;

        FaunaConfig config = FaunaConfig.get();
        int totalChicks = config.eggHatchMin + level.getRandom().nextInt(
                Math.max(1, config.eggHatchMax - config.eggHatchMin + 1));
        // Vanilla has already created the first chick, so this adds the rest.
        for (int i = 1; i < totalChicks; i++) {
            Chicken chick = new Chicken(EntityType.CHICKEN, level);
            chick.setBaby(true);
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0;
            double radius = 0.25 + level.getRandom().nextDouble() * 0.35;
            chick.moveTo(egg.getX() + Math.cos(angle) * radius, egg.getY(),
                    egg.getZ() + Math.sin(angle) * radius, level.getRandom().nextFloat() * 360.0F, 0.0F);
            level.addFreshEntity(chick);
        }
    }
}
