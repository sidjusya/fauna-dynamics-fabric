package com.faunadynamics.mixin;

import com.faunadynamics.config.FaunaConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.animal.feline.Cat;
import net.minecraft.world.entity.animal.wolf.Wolf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Animal.class)
abstract class AnimalBreedingMixin {
    @Inject(method = "spawnChildFromBreeding", at = @At("TAIL"), require = 0)
    private void faunaDynamics$spawnLitter(ServerLevel level, Animal partner, CallbackInfo ci) {
        Animal parent = (Animal) (Object) this;
        int totalChildren = 1;
        FaunaConfig config = FaunaConfig.get();

        if (parent instanceof Cat && partner instanceof Cat) {
            totalChildren = randomBetween(level, config.catLitterMin, config.catLitterMax);
        } else if (parent instanceof Wolf wolf && partner instanceof Wolf mate && wolf.isTame() && mate.isTame()) {
            if (level.getRandom().nextFloat() >= config.wolfSinglePupChance) {
                totalChildren = randomBetween(level, config.wolfLitterMinWhenMultiple,
                        config.wolfLitterMaxWhenMultiple);
            }
        } else if (parent instanceof Chicken && partner instanceof Chicken) {
            totalChildren = randomBetween(level, config.chickenLitterMin, config.chickenLitterMax);
        }

        // Vanilla already spawned one baby. Add only the remaining members of the litter.
        for (int i = 1; i < totalChildren; i++) {
            AgeableMob baby = parent.getBreedOffspring(level, partner);
            if (baby == null) continue;

            double angle = level.getRandom().nextDouble() * Math.PI * 2.0;
            double radius = 0.35 + level.getRandom().nextDouble() * 0.45;
            baby.setBaby(true);
            baby.moveTo(parent.getX() + Math.cos(angle) * radius, parent.getY(),
                    parent.getZ() + Math.sin(angle) * radius, parent.getYRot(), 0.0F);
            parent.finalizeSpawnChildFromBreeding(level, partner, baby);
            level.addFreshEntity(baby);
        }
    }

    private static int randomBetween(ServerLevel level, int min, int max) {
        return min + level.getRandom().nextInt(Math.max(1, max - min + 1));
    }
}
