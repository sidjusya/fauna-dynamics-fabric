package com.faunadynamics.behavior;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** Persistent vanilla entity tags used for lightweight per-animal traits. */
public final class AnimalTags {
    private static final String SEX_SET = "faunadynamics.sex_set";
    private static final String MALE = "faunadynamics.male";

    private AnimalTags() {
    }

    public static boolean ensureMale(Entity entity, Level level, float chance) {
        if (!entity.entityTags().contains(SEX_SET)) {
            entity.addTag(SEX_SET);
            if (level.getRandom().nextFloat() < chance) {
                entity.addTag(MALE);
            }
        }
        return entity.entityTags().contains(MALE);
    }

    public static boolean isMale(Entity entity) {
        return entity.entityTags().contains(MALE);
    }
}
