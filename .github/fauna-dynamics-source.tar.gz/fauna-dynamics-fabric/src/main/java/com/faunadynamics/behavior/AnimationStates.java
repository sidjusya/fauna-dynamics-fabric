package com.faunadynamics.behavior;

/** Stable IDs shared by server behavior and client-side native model animation hooks. */
public final class AnimationStates {
    public static final int NONE = 0;
    public static final int HORSE_KICK = 1;
    public static final int RAM_PREPARE = 2;
    public static final int RAM_IMPACT = 3;
    public static final int GOAT_PREPARE = 4;
    public static final int GOAT_IMPACT = 5;
    public static final int BULL_CHARGE = 6;
    public static final int CAT_PLAY = 7;
    public static final int DOG_DIG = 8;
    public static final int DOG_PLAY = 9;

    private AnimationStates() {
    }
}
