package com.faunadynamics.behavior;

import com.faunadynamics.config.FaunaConfig;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.entity.animal.equine.Horse;
import net.minecraft.world.entity.animal.feline.Cat;
import net.minecraft.world.entity.animal.goat.Goat;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.skeleton.Skeleton;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Server-authoritative behavior coordinator. Runs at a low cadence to avoid per-tick scans. */
public final class AnimalBehaviorController {
    private static final Map<UUID, Long> NEXT_ACTION_TICK = new HashMap<>();
    private static final Map<UUID, Long> ACTION_END_TICK = new HashMap<>();
    private static final Map<UUID, Integer> ACTIVE_ACTIONS = new HashMap<>();
    private static final Map<UUID, Integer> LAST_BULL_HIT = new HashMap<>();
    private static final Map<UUID, BullRetaliation> BULL_RETALIATIONS = new HashMap<>();
    private static long lastCleanupTick;

    private AnimalBehaviorController() {
    }

    public static void register() {
        ServerTickEvents.END_LEVEL_TICK.register(AnimalBehaviorController::tickLevel);
    }

    private static void tickLevel(ServerLevel level) {
        long now = level.getGameTime();
        if (now % 5L != 0L) return;

        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof Mob mob) clearExpiredAction(mob, now);
            if (entity instanceof Horse horse) tickHorse(level, horse, now);
            else if (entity instanceof Sheep sheep) tickSheep(level, sheep, now);
            else if (entity instanceof Goat goat) tickGoat(level, goat, now);
            else if (entity instanceof Cow cow) tickCow(level, cow, now);
            else if (entity instanceof Cat cat) tickCat(level, cat, now);
            else if (entity instanceof Wolf wolf) tickWolf(level, wolf, now);
            else if (entity instanceof Chicken chicken) tickChicken(level, chicken, now);
        }

        if (now - lastCleanupTick >= 1200L) {
            cleanup(level);
            lastCleanupTick = now;
        }
    }

    private static void tickHorse(ServerLevel level, Horse horse, long now) {
        FaunaConfig config = FaunaConfig.get();
        if (horse.isBaby() || horse.isTamed() || horse.isVehicle() || !horse.onGround()
                || now % config.horseKickCheckTicks != 0L) return;
        if (level.getRandom().nextFloat() >= config.horseKickChance) return;

        LivingEntity threat = nearestLiving(horse, 4.25, candidate ->
                (candidate instanceof Player || candidate instanceof Mob) && isBehind(horse, candidate));
        if (threat == null) return;

        Vec3 away = threat.position().subtract(horse.position()).normalize();
        playAnimation(horse, AnimationStates.HORSE_KICK, now, 18L);
        float damage = config.horseKickDamage;
        threat.hurtServer(level, level.damageSources().mobAttack(horse), damage);
        threat.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, config.horseKickSlownessTicks, 0), horse);
        threat.push(away.scale(0.8).add(0.0, 0.22, 0.0));
        setCooldown(horse, now, 60L);
    }

    private static boolean isBehind(Entity animal, Entity candidate) {
        Vec3 towardCandidate = candidate.position().subtract(animal.position()).normalize();
        return animal.getLookAngle().dot(towardCandidate) < -0.15;
    }

    private static void tickSheep(ServerLevel level, Sheep sheep, long now) {
        if (sheep.isBaby()) return;
        FaunaConfig config = FaunaConfig.get();
        boolean ram = ensureSex(sheep, level, config.ramRatio);
        if (!ram || !canAct(sheep, now)) return;
        if (now % config.socialCheckTicks != 0L || level.getRandom().nextFloat() >= config.ramFightChance) return;

        // Rams only compete when there are adult ewes nearby.
        Sheep ewe = nearestEntity(sheep, Sheep.class, 10.0,
                other -> other != sheep && !other.isBaby() && !ensureSex(other, level, config.ramRatio));
        if (ewe == null) return;

        Sheep rival = nearestEntity(sheep, Sheep.class, 8.0,
                other -> other != sheep && !other.isBaby() && canAct(other, now)
                        && ensureSex(other, level, config.ramRatio));
        if (rival == null) return;
        playAnimation(sheep, AnimationStates.RAM_PREPARE, now, 24L);
        sheep.getNavigation().moveTo(rival, 1.15);
        if (sheep.distanceToSqr(rival) <= 5.0) {
            playAnimation(sheep, AnimationStates.RAM_IMPACT, now, 8L);
            playAnimation(rival, AnimationStates.RAM_IMPACT, now, 8L);
            sheep.getNavigation().stop();
            rival.getNavigation().stop();
            shovePair(sheep, rival, 0.48);
            setCooldown(sheep, now, 200L);
            setCooldown(rival, now, 200L);
        }
    }

    private static void tickGoat(ServerLevel level, Goat goat, long now) {
        if (goat.isBaby() || !canAct(goat, now)) return;
        FaunaConfig config = FaunaConfig.get();
        if (!ensureSex(goat, level, config.goatMaleRatio)) return;
        if (now % config.socialCheckTicks != 0L || level.getRandom().nextFloat() >= config.goatButtChance) return;

        Goat rival = nearestEntity(goat, Goat.class, 7.0,
                other -> other != goat && !other.isBaby() && canAct(other, now)
                        && ensureSex(other, level, config.goatMaleRatio));
        if (rival == null) return;
        playAnimation(goat, AnimationStates.GOAT_PREPARE, now, 20L);
        goat.getNavigation().moveTo(rival, 1.2);
        if (goat.distanceToSqr(rival) <= 4.0) {
            playAnimation(goat, AnimationStates.GOAT_IMPACT, now, 8L);
            playAnimation(rival, AnimationStates.GOAT_IMPACT, now, 8L);
            goat.getNavigation().stop();
            rival.getNavigation().stop();
            shovePair(goat, rival, 0.58);
            setCooldown(goat, now, 160L);
            setCooldown(rival, now, 160L);
        }
    }

    private static void tickCow(ServerLevel level, Cow cow, long now) {
        if (cow.isBaby()) return;
        FaunaConfig config = FaunaConfig.get();
        boolean bull = ensureSex(cow, level, config.bullRatio);
        if (!bull) return;

        int hitTimestamp = cow.getLastHurtByMobTimestamp();
        int lastProcessed = LAST_BULL_HIT.getOrDefault(cow.getUUID(), -1);
        if (hitTimestamp > 0 && hitTimestamp != lastProcessed) {
            LAST_BULL_HIT.put(cow.getUUID(), hitTimestamp);
            LivingEntity attacker = cow.getLastAttacker();
            if (attacker instanceof Player) {
                BULL_RETALIATIONS.put(cow.getUUID(), new BullRetaliation(attacker.getUUID(), config.bullAttackCount, now));
            }
        }

        BullRetaliation retaliation = BULL_RETALIATIONS.get(cow.getUUID());
        if (retaliation == null) return;
        Entity targetEntity = level.getEntity(retaliation.target());
        if (!(targetEntity instanceof Player target) || !target.isAlive() || now - retaliation.startedAt() > 100L) {
            BULL_RETALIATIONS.remove(cow.getUUID());
            return;
        }

        if (cow.distanceToSqr(target) > 4.0) {
            playAnimation(cow, AnimationStates.BULL_CHARGE, now, 20L);
            cow.getNavigation().moveTo(target, 1.18);
            return;
        }
        if (now % 20L != 0L) return;

        playAnimation(cow, AnimationStates.BULL_CHARGE, now, 10L);
        target.hurtServer(level, level.damageSources().mobAttack(cow), (float) config.bullDamage);
        int remaining = retaliation.remaining() - 1;
        if (remaining <= 0) {
            Vec3 retreat = cow.position().subtract(target.position()).normalize();
            cow.push(retreat.scale(0.75).add(0.0, 0.12, 0.0));
            cow.getNavigation().stop();
            BULL_RETALIATIONS.remove(cow.getUUID());
        } else {
            BULL_RETALIATIONS.put(cow.getUUID(), new BullRetaliation(retaliation.target(), remaining, retaliation.startedAt()));
        }
    }

    private static void tickCat(ServerLevel level, Cat cat, long now) {
        if (cat.isOrderedToSit()) return;
        if (cat.isBaby()) {
            followYoungAnimal(level, cat, now);
            return;
        }
        if (!canAct(cat, now)) return;
        FaunaConfig config = FaunaConfig.get();
        if (now % config.socialCheckTicks != 0L || level.getRandom().nextFloat() >= config.catPlayChance) return;

        ItemEntity toy = nearestEntity(cat, ItemEntity.class, 6.0, item -> !item.getItem().isEmpty());
        if (toy != null) {
            playAnimation(cat, AnimationStates.CAT_PLAY, now, 30L);
            if (cat.distanceToSqr(toy) < 2.25) {
                Vec3 nudge = toy.position().subtract(cat.position()).normalize();
                toy.push(nudge.scale(0.18).add(0.0, 0.08, 0.0));
                cat.getNavigation().stop();
            } else {
                cat.getNavigation().moveTo(toy, 1.15);
            }
            setCooldown(cat, now, 160L);
            return;
        }
        Cat playmate = nearestEntity(cat, Cat.class, 6.0, other -> other != cat && !other.isBaby());
        if (playmate != null) {
            playAnimation(cat, AnimationStates.CAT_PLAY, now, 30L);
            cat.getNavigation().moveTo(playmate, 1.2);
            if (cat.distanceToSqr(playmate) < 3.0) {
                shovePair(cat, playmate, 0.12);
                setCooldown(cat, now, 180L);
                setCooldown(playmate, now, 180L);
            }
            return;
        }

        Animal playTarget = nearestEntity(cat, Animal.class, 4.5,
                other -> other != cat && !(other instanceof Cat) && !(other instanceof Wolf) && !other.isBaby());
        if (playTarget != null) {
            playAnimation(cat, AnimationStates.CAT_PLAY, now, 24L);
            if (cat.distanceToSqr(playTarget) < 2.5) {
                Vec3 playfulNudge = cat.position().subtract(playTarget.position()).normalize();
                playTarget.push(playfulNudge.scale(0.10).add(0.0, 0.04, 0.0));
                cat.getNavigation().stop();
            } else {
                cat.getNavigation().moveTo(playTarget, 1.1);
            }
            setCooldown(cat, now, 160L);
        }
    }

    private static void tickWolf(ServerLevel level, Wolf wolf, long now) {
        if (!wolf.isTame() || wolf.isOrderedToSit() || wolf.isLeashed()) return;
        if (wolf.isBaby()) {
            followYoungAnimal(level, wolf, now);
            return;
        }
        if (!canAct(wolf, now)) return;
        FaunaConfig config = FaunaConfig.get();
        if (now % config.socialCheckTicks != 0L) return;

        if (level.getRandom().nextFloat() < config.dogDigChance) {
            playAnimation(wolf, AnimationStates.DOG_DIG, now, 35L);
            level.sendParticles(ParticleTypes.POOF, wolf.getX(), wolf.getY() + 0.08, wolf.getZ(),
                    4, 0.22, 0.04, 0.22, 0.01);
            setCooldown(wolf, now, 240L);
            return;
        }

        if (level.getRandom().nextFloat() < config.dogPlayChance) {
            Wolf playmate = nearestEntity(wolf, Wolf.class, 7.0, other -> other != wolf && other.isTame() && !other.isBaby());
            if (playmate != null) {
                playAnimation(wolf, AnimationStates.DOG_PLAY, now, 30L);
                wolf.getNavigation().moveTo(playmate, 1.25);
                if (wolf.distanceToSqr(playmate) < 3.0) {
                    shovePair(wolf, playmate, 0.10);
                    setCooldown(wolf, now, 180L);
                    setCooldown(playmate, now, 180L);
                }
                return;
            }
        }

        // Playful practice chase: approach, make a small hop and disengage. This goal never deals damage.
        if (level.getRandom().nextFloat() < config.dogChaseChance) {
            Sheep practiceTarget = nearestEntity(wolf, Sheep.class, 9.0,
                    sheep -> !sheep.isBaby() && !sheep.isLeashed());
            if (practiceTarget != null) {
                playAnimation(wolf, AnimationStates.DOG_PLAY, now, 24L);
                if (wolf.distanceToSqr(practiceTarget) < 3.0) {
                    Vec3 hop = practiceTarget.position().subtract(wolf.position()).normalize();
                    wolf.push(hop.scale(0.28).add(0.0, 0.28, 0.0));
                    wolf.getNavigation().stop();
                    setCooldown(wolf, now, 140L);
                } else {
                    wolf.getNavigation().moveTo(practiceTarget, 1.25);
                    setCooldown(wolf, now, 100L);
                }
                return;
            }

            // A playful investigation of a nearby skeleton; this behavior itself never attacks it.
            Skeleton skeleton = nearestEntity(wolf, Skeleton.class, 8.0, Entity::isAlive);
            if (skeleton != null && wolf.getTarget() == null) {
                playAnimation(wolf, AnimationStates.DOG_PLAY, now, 24L);
                if (wolf.distanceToSqr(skeleton) < 4.0) {
                    wolf.getNavigation().stop();
                    setCooldown(wolf, now, 140L);
                } else {
                    wolf.getNavigation().moveTo(skeleton, 1.2);
                    setCooldown(wolf, now, 100L);
                }
            }
        }
    }

    private static void tickChicken(ServerLevel level, Chicken chicken, long now) {
        if (!chicken.isBaby()) return;
        followYoungAnimal(level, chicken, now);
    }

    private static void followYoungAnimal(ServerLevel level, Mob baby, long now) {
        if (now % 20L != 0L) return;
        Mob parent = null;
        double bestDistance = 12.0 * 12.0;
        for (Entity candidate : level.getEntities(null, baby.getBoundingBox().inflate(12.0),
                entity -> entity instanceof Mob mob && mob.getClass() == baby.getClass() && !mob.isBaby())) {
            double distance = baby.distanceToSqr(candidate);
            if (distance < bestDistance) {
                bestDistance = distance;
                parent = (Mob) candidate;
            }
        }
        if (parent != null && bestDistance > 2.25) {
            baby.getNavigation().moveTo(parent, 1.15);
        }
    }

    private static void shovePair(Entity first, Entity second, double strength) {
        Vec3 direction = second.position().subtract(first.position());
        if (direction.lengthSqr() < 0.0001) direction = new Vec3(1.0, 0.0, 0.0);
        direction = direction.normalize();
        first.push(direction.scale(-strength).add(0.0, 0.08, 0.0));
        second.push(direction.scale(strength).add(0.0, 0.08, 0.0));
    }

    private static boolean ensureSex(Mob animal, ServerLevel level, float maleChance) {
        return AnimalTags.ensureMale(animal, level, maleChance);
    }

    private static void playAnimation(Mob mob, int action, long now, long duration) {
        // Logical action state. A dedicated client payload will feed native model poses in a later pass.
        ACTIVE_ACTIONS.put(mob.getUUID(), action);
        ACTION_END_TICK.put(mob.getUUID(), now + duration);
    }

    private static void clearExpiredAction(Mob mob, long now) {
        Long endTick = ACTION_END_TICK.get(mob.getUUID());
        if (endTick != null && now >= endTick) {
            ACTIVE_ACTIONS.remove(mob.getUUID());
            ACTION_END_TICK.remove(mob.getUUID());
        }
    }

    private static boolean canAct(Entity entity, long now) {
        return now >= NEXT_ACTION_TICK.getOrDefault(entity.getUUID(), 0L);
    }

    private static void setCooldown(Entity entity, long now, long duration) {
        NEXT_ACTION_TICK.put(entity.getUUID(), now + duration);
    }

    private static <T extends LivingEntity> T nearestEntity(Entity source, Class<T> type, double range,
                                                             java.util.function.Predicate<T> predicate) {
        T nearest = null;
        double bestDistance = range * range;
        for (T candidate : source.level().getEntitiesOfClass(type, source.getBoundingBox().inflate(range),
                entity -> entity != source && entity.isAlive() && predicate.test(entity))) {
            double distance = source.distanceToSqr(candidate);
            if (distance < bestDistance) {
                bestDistance = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private static LivingEntity nearestLiving(Entity source, double range,
                                               java.util.function.Predicate<LivingEntity> predicate) {
        return nearestEntity(source, LivingEntity.class, range, predicate);
    }

    private static void cleanup(ServerLevel level) {
        NEXT_ACTION_TICK.keySet().removeIf(uuid -> level.getEntityInAnyDimension(uuid) == null);
        ACTION_END_TICK.keySet().removeIf(uuid -> level.getEntityInAnyDimension(uuid) == null);
        ACTIVE_ACTIONS.keySet().removeIf(uuid -> level.getEntityInAnyDimension(uuid) == null);
        LAST_BULL_HIT.keySet().removeIf(uuid -> level.getEntityInAnyDimension(uuid) == null);
        BULL_RETALIATIONS.keySet().removeIf(uuid -> level.getEntityInAnyDimension(uuid) == null);
        if (NEXT_ACTION_TICK.size() > 20_000) NEXT_ACTION_TICK.clear();
        if (LAST_BULL_HIT.size() > 20_000) LAST_BULL_HIT.clear();
        if (BULL_RETALIATIONS.size() > 2_000) BULL_RETALIATIONS.clear();
        if (ACTIVE_ACTIONS.size() > 20_000) ACTIVE_ACTIONS.clear();
    }

    private record BullRetaliation(UUID target, int remaining, long startedAt) {
    }
}
