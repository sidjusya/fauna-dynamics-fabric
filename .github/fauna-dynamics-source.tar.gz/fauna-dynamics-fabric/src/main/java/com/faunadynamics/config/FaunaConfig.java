package com.faunadynamics.config;

import com.faunadynamics.FaunaDynamics;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Simple user-editable configuration. Values are clamped after loading. */
public final class FaunaConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fauna-dynamics.json");

    public float horseKickChance = 0.20F;
    public float horseKickDamage = 9.0F; // 4.5 hearts
    public int horseKickSlownessTicks = 60;
    public int horseKickCheckTicks = 100;

    public float ramRatio = 0.30F;
    public float bullRatio = 0.15F;
    public float goatMaleRatio = 0.35F;
    public float ramFightChance = 0.08F;
    public float goatButtChance = 0.04F;

    public int bullDamage = 4; // 2 hearts
    public int bullAttackCount = 2;

    public int catLitterMin = 3;
    public int catLitterMax = 6;
    public float wolfSinglePupChance = 0.50F;
    public int wolfLitterMinWhenMultiple = 2;
    public int wolfLitterMaxWhenMultiple = 3;
    public int chickenLitterMin = 2;
    public int chickenLitterMax = 4;
    public int eggHatchMin = 2;
    public int eggHatchMax = 3;

    public int socialCheckTicks = 100;
    public float catPlayChance = 0.12F;
    public float dogPlayChance = 0.10F;
    public float dogDigChance = 0.04F;
    public float dogChaseChance = 0.04F;

    private static FaunaConfig current = new FaunaConfig();

    private FaunaConfig() {
    }

    public static FaunaConfig get() {
        return current;
    }

    public static void load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE)) {
                    FaunaConfig loaded = GSON.fromJson(reader, FaunaConfig.class);
                    if (loaded != null) current = loaded;
                }
            }
            current.clamp();
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(current, writer);
            }
            FaunaDynamics.LOGGER.info("Loaded configuration from {}", FILE);
        } catch (Exception exception) {
            current = new FaunaConfig();
            FaunaDynamics.LOGGER.error("Could not load Fauna Dynamics config; using defaults.", exception);
        }
    }

    private void clamp() {
        horseKickChance = clamp(horseKickChance, 0.0F, 1.0F);
        horseKickDamage = clamp(horseKickDamage, 0.0F, 40.0F);
        horseKickSlownessTicks = clamp(horseKickSlownessTicks, 0, 20 * 60);
        horseKickCheckTicks = roundToFiveTicks(clamp(horseKickCheckTicks, 20, 20 * 60));
        ramRatio = clamp(ramRatio, 0.0F, 1.0F);
        bullRatio = clamp(bullRatio, 0.0F, 1.0F);
        goatMaleRatio = clamp(goatMaleRatio, 0.0F, 1.0F);
        ramFightChance = clamp(ramFightChance, 0.0F, 1.0F);
        goatButtChance = clamp(goatButtChance, 0.0F, 1.0F);
        bullDamage = clamp(bullDamage, 0, 40);
        bullAttackCount = clamp(bullAttackCount, 1, 10);
        catLitterMin = clamp(catLitterMin, 1, 8);
        catLitterMax = clamp(catLitterMax, catLitterMin, 8);
        wolfSinglePupChance = clamp(wolfSinglePupChance, 0.0F, 1.0F);
        wolfLitterMinWhenMultiple = clamp(wolfLitterMinWhenMultiple, 2, 8);
        wolfLitterMaxWhenMultiple = clamp(wolfLitterMaxWhenMultiple, wolfLitterMinWhenMultiple, 8);
        chickenLitterMin = clamp(chickenLitterMin, 1, 8);
        chickenLitterMax = clamp(chickenLitterMax, chickenLitterMin, 8);
        eggHatchMin = clamp(eggHatchMin, 1, 8);
        eggHatchMax = clamp(eggHatchMax, eggHatchMin, 8);
        socialCheckTicks = roundToFiveTicks(clamp(socialCheckTicks, 20, 20 * 60));
        catPlayChance = clamp(catPlayChance, 0.0F, 1.0F);
        dogPlayChance = clamp(dogPlayChance, 0.0F, 1.0F);
        dogDigChance = clamp(dogDigChance, 0.0F, 1.0F);
        dogChaseChance = clamp(dogChaseChance, 0.0F, 1.0F);
    }

    private static int roundToFiveTicks(int ticks) {
        return Math.max(20, Math.round(ticks / 5.0F) * 5);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
