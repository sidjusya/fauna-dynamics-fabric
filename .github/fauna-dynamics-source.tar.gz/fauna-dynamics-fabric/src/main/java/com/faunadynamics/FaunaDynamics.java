package com.faunadynamics;

import com.faunadynamics.behavior.AnimalBehaviorController;
import com.faunadynamics.config.FaunaConfig;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class FaunaDynamics implements ModInitializer {
    public static final String MOD_ID = "faunadynamics";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        FaunaConfig.load();
        AnimalBehaviorController.register();
        LOGGER.info("Fauna Dynamics initialized for Minecraft 26.3.");
    }
}
